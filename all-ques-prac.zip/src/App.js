import React from 'react';
import UseCallbackDemo from './hooks/UseCallbackDemo';
import UseContextDemo from './hooks/UseContextDemo';
import UseEffectDemo from './hooks/UseEffectDemo';
import UseMemoDemo from './hooks/UseMemoDemo';
import UseReducerDemo from './hooks/UseReducerDemo';
import UseRefDemo from './hooks/UseRefDemo';
import CurrencyConverter from './Components/CurrencyConverter';
import QuizApp from './Components/QuizApp';
import Timer from './Components/Timer';
import MyForm from './Components/From';
import ClickCount from './Components/ClickCount';
import ToggleSwitch from './Components/ToggleSwitch';
import DataFetcher from './Components/DataFetcher';
import Modal from './Components/Modal';
import Slider from './Components/Slider';
// import { configureStore } from '@reduxjs/toolkit';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Counter from './Redux-router/Counter';
// import About from './Redux-router/About';
// import Home from './Redux-router/Home';
// import { Provider } from 'react-redux';
// import counterReducer from './Redux-router/CounterSlice'
// const store = configureStore(counterReducer);
function App() {
  return (
    <>
      <Slider/>
      <hr/>
      <DataFetcher/>
      <Modal/>
      <ToggleSwitch />
      <hr />
      <ClickCount/>
      <hr/>
      <Timer />
      <CurrencyConverter />
      <hr/>
      <UseEffectDemo/>
      <UseContextDemo/>
      <UseRefDemo/>
      <UseReducerDemo/>
      <UseCallbackDemo/>
      <UseMemoDemo/>
      <hr/>
      <QuizApp/>
      <hr/>
      <MyForm />
      {/* <hr/>
      <Provider store={store}>
        <Router>
          <div className='container'>
            <Routes>
              <Route path="/" element={<Counter/>} />
              <Route path="/about" element={<About />} />
              <Route path="/home" element={<Home />} />
            </Routes>
          </div>
        </Router>
      </Provider> */}
    </>
  );
}

export default App;
